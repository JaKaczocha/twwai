# TWwAI_Kol2

    Zbudowanie (uzupełnienie) aplikacji - serwer z 2 ścieżkami.

    GET - pobranie wszystkich odczytów
    POST - dodanie nowego odczytu

    dodatnie nowego controllera w aplikacji serwerowej - przy połączeniu do bazy danych proszę zamienić "paramsXY" na params + swoje inicjały. Spowoduje to, że każdy będzie miał oddzielną kolekcję w bazie danych,
    nazwy ścieżek do ustalenia przez realizującego.

Odczyt = (temperatura, ciśnienie, wilgotność - powietrza, aktualna data - format DD:MM HH:mm:ss)

    Zbudowanie aplikacji klienckiej (React + charts.js) - polecenie Vite

    Vite:
    1. Tworzenie nowego projektu:
    bash
    npm create vite
    cd nazwa-projektu
    2. Uruchamianie aplikacji w trybie deweloperskim:
    bash
    npm run dev
    
    (szablon TypeScript)
    

    Wyświetlanie pomiarów pobranych z serwera

    Dodanie nowych odczytów za pomocą POSTMAN
